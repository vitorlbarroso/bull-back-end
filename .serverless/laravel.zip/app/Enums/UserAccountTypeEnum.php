<?php

namespace App\Enums;

enum UserAccountTypeEnum:string
{
    case PF = "PF";
    case PJ = "PJ";
}
