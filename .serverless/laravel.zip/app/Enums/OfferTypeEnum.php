<?php

namespace App\Enums;

enum OfferTypeEnum:string
{
    case Recurrence = "Recurrence";
    case Unic = "Unic";
}
