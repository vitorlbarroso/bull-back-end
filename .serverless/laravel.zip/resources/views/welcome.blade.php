<?php

header("Location: https://flamepay.com.br");
die();
